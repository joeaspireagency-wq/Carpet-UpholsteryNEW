# Fibrewell Carpet & Upholstery Care

Front-end prototype for a fictional UK carpet and upholstery cleaning business (Coventry). One self-contained HTML page: no build tools, no dependencies, no backend.

**Primary CTA:** "Get Your Free Quote" opens a five-step quote popup. The page shows two CTA buttons (hero and closing section) plus a sticky bar on mobile.

## Run it

Open `index.html` in a browser. That's it.

To publish on GitHub Pages: push this folder, then go to Settings > Pages and serve from the `main` branch root. The `.nojekyll` file is already included.

## What's in the page

- Hero with blurred technician photo, trust strip, services, pricing, "Clean, careful and dry fast" steps
- Before/after photo slider, review slider, owner section, FAQ, closing CTA, footer (options A to D, B is the default)
- Quote popup: service, size, timing, postcode (CV and B90 to B94 coverage check), contact details, success and error states
- Floating WhatsApp button on laptop; sticky "Get Your Free Quote" + phone button on mobile
- Preview toolbar at the top to switch between Laptop and Mobile views and footer options. It is for prototyping only; strip it (and the device frame around the site) before turning the page into a real site.

## Project layout

```
index.html          the finished page (generated, safe to open directly)
assets/             original photos (hero, owner, before, after)
src/1-styles.html   head + all CSS
src/2-markup.html   page markup
src/3-script.html   all JavaScript (data, renderers, quote popup, mock connector)
src/build.py        rebuilds index.html and embeds the photos as base64
PLACEHOLDERS.md     everything invented that must be replaced before launch
```

Edit the files in `src/`, then run:

```
python3 src/build.py
```

## Before using this for a real business

Read `PLACEHOLDERS.md`. Prices, reviews, rating, badges, phone number, WhatsApp number, company number and the owner photo are all demonstration content. The quote form sends nothing: `submitQuote` is a mock that returns a made-up reference.

## Tech notes

- Plain HTML, CSS and JavaScript. Fonts: Plus Jakarta Sans and Inter from Google Fonts.
- Responsive through CSS container queries, so the Laptop / Mobile toggle gives true layouts.
- Respects `prefers-reduced-motion`. Contrast checked against WCAG AA.
