# PLACEHOLDERS.md: Fibrewell Carpet & Upholstery Care

Everything below is invented for the prototype. Replace each item with the real business's facts before any launch. The visible "demo" and "placeholder" labels have been removed from the page, so this file is now the only record of what is fake. In `index.html`, rendered elements carry a `data-placeholder="..."` attribute so they can be found with a simple search.

## Business facts
- Business name, owner (Neil Parsons), founded 2015, Coventry location, areas covered, opening hours
- Phone 07700 900214 and hello@fibrewell.example
- "Company no. 00000000" in footer option B
- Founder story and owner quote

## WhatsApp
- The laptop floating button links to `wa.me/447700900214`. Replace with the real WhatsApp number.

## Photos
- Hero background, owner photo, and before/after photos are stand-in images (`assets/`). Replace with real photographs of the real business, with permission from homeowners.

## Ratings and reviews (`data-placeholder="review" | "rating-badge"`)
- "Rated 4.9 from 214 customers" under the "Real homes. Real results." heading
- Six reviews in the slider (Hannah R., Mo K., Janet and Colin B., Priya S., Tom D., Gemma L.)
- Before/after job details (Earlsdon lounge and hall carpet: problem, treatment, stains, drying)

## Trust badges (`data-placeholder="trust-badge"`)
- "Since 2015", "Insured", "Re-clean guarantee", "Trade body badge" in the trust strip and footers
- No real accreditation (NCCA, IICRC, Woolsafe, CRI) is implied. Add real badges only with real evidence.

## Prices (`data-placeholder="price"`)
- Clean £35, Clean + Protect £49, Total Care £65 (per room, from, inc. VAT)
- Minimum job £75, no call-out fee, whole-home bundle from £179
- Re-clean guarantee periods of 7, 14 and 30 days
- Price guide, add-ons, business rates and the Fresh Start plan still exist in the data in `src/3-script.html` but are no longer shown on the page.

## Claims
- Drying times, "call-back within the hour", "Monday to Saturday 8am to 6pm", "slots usually available within the week"
- Guarantee wording must be backed by the real business's written terms.

## Quote popup and connector
- `submitQuote` runs in demo mode only: about 900ms simulated delay, fake reference `FW-####`, no network request, nothing stored.
- The real transport (Web3Forms or Formspree) is a `// TODO` stub. Implement it only from the provider's official documentation.
- Dev flag: run `fibrewellDev.failNext()` in the browser console to see the error state with retry.

## Not included on purpose
- No `aggregateRating` in the JSON-LD, because the 4.9 figure is not real.

## Preview toolbar
- The dark bar at the top (Laptop / Mobile and footer options) is for prototyping only. Remove it for a live site.
