"""Rebuild index.html from the source parts. Run from the repo root:  python3 src/build.py
Photos in /assets are embedded as base64 so index.html stays a single self-contained file."""
import base64, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
b64 = lambda name: base64.b64encode((root / 'assets' / name).read_bytes()).decode()
css = (root / 'src/1-styles.html').read_text()
html = (root / 'src/2-markup.html').read_text()
js = (root / 'src/3-script.html').read_text()
css = css.replace('/*HERO_IMG*/', b64('hero-technician.jpg'))
js = (js.replace('/*OWNER_IMG*/', b64('owner-neil.jpg'))
        .replace('/*BA_BEFORE*/', b64('before.jpg'))
        .replace('/*BA_AFTER*/', b64('after.jpg')))
(root / 'index.html').write_text(css + html + js)
print('index.html rebuilt,', round((root / 'index.html').stat().st_size / 1024), 'KB')
